import MadlogApp from '@/pages/MadlogApp';

function App() {
  return <MadlogApp />;
}

export default App;
