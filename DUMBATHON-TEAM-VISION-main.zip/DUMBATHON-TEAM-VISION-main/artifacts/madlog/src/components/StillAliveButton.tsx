import React, { useEffect, useState } from 'react';

interface StillAliveButtonProps {
  onConfirm: () => void;
  timeRemaining: number;
}

export default function StillAliveButton({ onConfirm, timeRemaining }: StillAliveButtonProps) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Random position on screen
    const x = Math.random() * (window.innerWidth - 200);
    const y = Math.random() * (window.innerHeight - 100);
    setPosition({ x: Math.max(10, x), y: Math.max(10, y) });
    
    // Fade in animation
    setTimeout(() => setIsVisible(true), 50);
  }, []);

  const urgency = timeRemaining < 15 ? 'critical' : timeRemaining < 30 ? 'warning' : 'normal';
  
  const backgroundColor = 
    urgency === 'critical' ? '#330000' : 
    urgency === 'warning' ? '#331100' : 
    '#0a1a0a';
    
  const borderColor = 
    urgency === 'critical' ? '#cc0000' : 
    urgency === 'warning' ? '#cc6600' : 
    '#4a7a4a';
    
  const textColor = 
    urgency === 'critical' ? '#ff3333' : 
    urgency === 'warning' ? '#ff9933' : 
    '#5a8a5a';

  return (
    <div
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        zIndex: 10000,
        backgroundColor,
        border: `2px solid ${borderColor}`,
        padding: '16px 20px',
        boxShadow: '0 0 20px rgba(0,0,0,0.8)',
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? 'scale(1)' : 'scale(0.8)',
        transition: 'all 0.3s ease-out',
        animation: urgency === 'critical' ? 'pulse 0.5s infinite' : 'none',
      }}
    >
      <div style={{ 
        fontSize: 11, 
        color: textColor, 
        letterSpacing: 3, 
        fontFamily: "'Courier New', monospace",
        marginBottom: 8,
        fontWeight: 'bold',
      }}>
        {urgency === 'critical' ? '⚠ CRITICAL' : urgency === 'warning' ? '⚠ WARNING' : '⚠ CONFIRMATION REQUIRED'}
      </div>
      
      <div style={{ 
        fontSize: 24, 
        color: textColor, 
        letterSpacing: 2, 
        fontFamily: "'Courier New', monospace",
        marginBottom: 12,
        fontWeight: 'bold',
      }}>
        {timeRemaining}s
      </div>
      
      <button
        onClick={onConfirm}
        style={{
          backgroundColor: urgency === 'critical' ? '#660000' : '#0d1a0d',
          border: `2px solid ${borderColor}`,
          color: textColor,
          padding: '12px 24px',
          cursor: 'pointer',
          fontSize: 13,
          letterSpacing: 3,
          fontFamily: "'Courier New', monospace",
          fontWeight: 'bold',
          width: '100%',
          transition: 'all 0.2s',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = urgency === 'critical' ? '#990000' : '#1a2a1a';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = urgency === 'critical' ? '#660000' : '#0d1a0d';
        }}
      >
        [ STILL ALIVE ]
      </button>
      
      <div style={{ 
        fontSize: 8, 
        color: '#334433', 
        letterSpacing: 2, 
        fontFamily: "'Courier New', monospace",
        marginTop: 8,
        textAlign: 'center',
      }}>
        CONFIRM PRESENCE OR LOSE DATA
      </div>
    </div>
  );
}
