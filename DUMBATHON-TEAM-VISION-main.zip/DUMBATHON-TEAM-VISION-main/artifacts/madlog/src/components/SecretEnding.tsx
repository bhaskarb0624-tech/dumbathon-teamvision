import React, { useEffect, useState } from 'react';

interface Props {
  onComplete: () => void;
}

const sequence = [
  { text: 'YOU ARE NOT THE SURVIVOR', delay: 0 },
  { text: 'YOU ARE THE LOG', delay: 3000 },
  { text: '', delay: 5000 },
  { text: 'SYSTEM REWRITING MEMORY', delay: 6000 },
  { text: '...', delay: 8500 },
  { text: '..........', delay: 9000 },
  { text: 'DONE', delay: 10000 },
];

export default function SecretEnding({ onComplete }: Props) {
  const [currentText, setCurrentText] = useState('');
  const [phase, setPhase] = useState(0);
  const [glitching, setGlitching] = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];

    sequence.forEach((item, idx) => {
      timers.push(
        setTimeout(() => {
          setCurrentText(item.text);
          setPhase(idx);
          if (item.text === 'SYSTEM REWRITING MEMORY') {
            setGlitching(true);
          }
        }, item.delay)
      );
    });

    timers.push(
      setTimeout(() => {
        setGlitching(false);
        onComplete();
      }, 12000)
    );

    return () => timers.forEach(clearTimeout);
  }, [onComplete]);

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: '#000000',
        zIndex: 999999,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        fontFamily: "'Courier New', monospace",
      }}
      className={glitching ? 'heavy-shake' : ''}
    >
      {phase < 6 && currentText && (
        <p
          style={{
            color: '#cc0000',
            fontSize: phase <= 1 ? 32 : phase === 3 ? 20 : 14,
            fontWeight: 'bold',
            letterSpacing: 6,
            textAlign: 'center',
            maxWidth: 600,
            padding: '0 24px',
            animation: 'text-appear 1s ease-out',
          }}
          className={glitching ? 'glitch-text' : ''}
          data-text={currentText}
        >
          {currentText}
        </p>
      )}
      {phase === 5 && (
        <p style={{ color: '#330000', fontSize: 12, letterSpacing: 4, marginTop: 16 }}>
          {Array(Math.floor(Math.random() * 20 + 10)).fill('01').join('')}
        </p>
      )}
    </div>
  );
}
