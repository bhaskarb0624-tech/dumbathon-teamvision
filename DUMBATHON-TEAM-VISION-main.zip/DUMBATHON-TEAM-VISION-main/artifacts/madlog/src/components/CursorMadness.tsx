import React, { useEffect, useRef, useState } from 'react';
import type { MadnessStage } from '../lib/chaos';

interface GhostCursor {
  id: string;
  x: number;
  y: number;
}

interface Props {
  stage: MadnessStage;
}

export default function CursorMadness({ stage }: Props) {
  const [ghosts, setGhosts] = useState<GhostCursor[]>([]);
  const [cursorHidden, setCursorHidden] = useState(false);
  const [inverted, setInverted] = useState(false);
  const ghostTrailRef = useRef<{ x: number; y: number }[]>([]);
  const lastPos = useRef({ x: 0, y: 0 });
  const invertedRef = useRef(false);

  useEffect(() => {
    invertedRef.current = inverted;
  }, [inverted]);

  useEffect(() => {
    if (stage < 3) return;

    const handleMouseMove = (e: MouseEvent) => {
      const pos = { x: e.clientX, y: e.clientY };
      lastPos.current = pos;
      ghostTrailRef.current.push(pos);
      if (ghostTrailRef.current.length > 5) ghostTrailRef.current.shift();

      if (stage >= 3 && Math.random() < 0.08) {
        const trailPos = ghostTrailRef.current[0] || pos;
        setGhosts(prev => [
          ...prev.slice(-8),
          {
            id: Math.random().toString(36).slice(2, 8),
            x: trailPos.x,
            y: trailPos.y,
          },
        ]);
        setTimeout(() => {
          setGhosts(prev => prev.slice(1));
        }, 400);
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, [stage]);

  useEffect(() => {
    if (stage < 3) return;

    const hideCursorInterval = setInterval(() => {
      if (Math.random() < 0.3) {
        setCursorHidden(true);
        document.body.style.cursor = 'none';
        setTimeout(() => {
          setCursorHidden(false);
          document.body.style.cursor = '';
        }, 1500 + Math.random() * 1500);
      }
    }, 8000 + Math.random() * 12000);

    return () => {
      clearInterval(hideCursorInterval);
      document.body.style.cursor = '';
    };
  }, [stage]);

  useEffect(() => {
    if (stage < 4) return;

    const invertInterval = setInterval(() => {
      if (Math.random() < 0.2) {
        setInverted(true);
        setTimeout(() => setInverted(false), 3000);
      }
    }, 12000);

    return () => clearInterval(invertInterval);
  }, [stage]);

  useEffect(() => {
    if (!inverted) return;

    const handleInvertedMove = (e: MouseEvent) => {
      e.stopPropagation();
    };

    document.addEventListener('mousemove', handleInvertedMove, true);
    return () => document.removeEventListener('mousemove', handleInvertedMove, true);
  }, [inverted]);

  return (
    <>
      {inverted && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 99990,
            pointerEvents: 'none',
            mixBlendMode: 'difference',
            backgroundColor: 'rgba(255, 255, 255, 0.03)',
          }}
        />
      )}
      {ghosts.map(ghost => (
        <div
          key={ghost.id}
          className="cursor-ghost"
          style={{
            left: ghost.x - 8,
            top: ghost.y - 8,
          }}
        />
      ))}
      {cursorHidden && (
        <div
          style={{
            position: 'fixed',
            bottom: 20,
            right: 20,
            color: '#cc0000',
            fontSize: '11px',
            fontFamily: 'monospace',
            letterSpacing: 2,
            zIndex: 99999,
            animation: 'blink 0.5s step-end infinite',
          }}
        >
          ⚠ STAY STILL
        </div>
      )}
    </>
  );
}
