import React, { useEffect, useState } from 'react';

interface ActionBlockingPopupProps {
  message: string;
  onDismiss: () => void;
}

const APOCALYPSE_MESSAGES = [
  '⚠ SYSTEM WARNING: Unauthorized action detected',
  '⚠ FACTION ALERT: Northern territories report movement',
  '⚠ SUPPLY SHORTAGE: Water rations reduced by 40%',
  '⚠ CRYPTIC MESSAGE: The sky turned red at dawn',
  '⚠ RADIATION SPIKE: Shelter in place immediately',
  '⚠ COMMUNICATION LOST: All outposts silent',
  '⚠ UNKNOWN SIGNAL: Triangulating source...',
  '⚠ BIOHAZARD DETECTED: Contamination level rising',
  '⚠ POWER FAILURE: Backup generators at 12%',
  '⚠ HOSTILE PRESENCE: Motion detected in sector 7',
  '⚠ SYSTEM BREACH: Someone is watching your screen',
  '⚠ FOOD RESERVES: 3 days remaining',
  '⚠ TEMPERATURE DROP: -15°C in the last hour',
  '⚠ SEISMIC ACTIVITY: Tremors detected nearby',
  '⚠ AIR QUALITY: Toxin levels unsafe',
  '⚠ EMERGENCY BROADCAST: Do not trust the broadcasts',
  '⚠ QUARANTINE ZONE: Your location is now restricted',
  '⚠ SURVIVOR COUNT: Population decreased by 23%',
  '⚠ NIGHT PROTOCOL: Darkness approaching',
  '⚠ ANOMALY DETECTED: Reality fluctuation in progress',
];

export default function ActionBlockingPopup({ message, onDismiss }: ActionBlockingPopupProps) {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);
  const [displayMessage] = useState(
    APOCALYPSE_MESSAGES[Math.floor(Math.random() * APOCALYPSE_MESSAGES.length)]
  );

  useEffect(() => {
    // Center on screen with slight randomness
    const x = (window.innerWidth / 2) - 200 + (Math.random() * 100 - 50);
    const y = (window.innerHeight / 2) - 100 + (Math.random() * 100 - 50);
    setPosition({ x: Math.max(10, x), y: Math.max(10, y) });
    
    setTimeout(() => setIsVisible(true), 50);
  }, []);

  return (
    <>
      {/* Backdrop */}
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.85)',
          zIndex: 15000,
          opacity: isVisible ? 1 : 0,
          transition: 'opacity 0.3s',
        }}
        onClick={onDismiss}
      />
      
      {/* Popup */}
      <div
        style={{
          position: 'fixed',
          left: position.x,
          top: position.y,
          zIndex: 15001,
          backgroundColor: '#0a0a0a',
          border: '2px solid #cc3333',
          padding: '24px',
          minWidth: 400,
          maxWidth: 500,
          boxShadow: '0 0 40px rgba(204, 51, 51, 0.5)',
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'scale(1)' : 'scale(0.9)',
          transition: 'all 0.3s ease-out',
        }}
      >
        <div style={{ 
          fontSize: 10, 
          color: '#cc3333', 
          letterSpacing: 4, 
          fontFamily: "'Courier New', monospace",
          marginBottom: 16,
          fontWeight: 'bold',
          textAlign: 'center',
        }}>
          SYSTEM INTERRUPT
        </div>
        
        <div style={{ 
          fontSize: 13, 
          color: '#ff6666', 
          letterSpacing: 1, 
          fontFamily: "'Courier New', monospace",
          marginBottom: 20,
          lineHeight: 1.6,
          textAlign: 'center',
        }}>
          {displayMessage}
        </div>
        
        <div style={{ 
          fontSize: 11, 
          color: '#666666', 
          letterSpacing: 1, 
          fontFamily: "'Courier New', monospace",
          marginBottom: 20,
          lineHeight: 1.5,
          textAlign: 'center',
          fontStyle: 'italic',
        }}>
          Action requested: {message}
        </div>
        
        <button
          onClick={onDismiss}
          style={{
            backgroundColor: '#1a0a0a',
            border: '2px solid #cc3333',
            color: '#ff6666',
            padding: '12px 24px',
            cursor: 'pointer',
            fontSize: 12,
            letterSpacing: 3,
            fontFamily: "'Courier New', monospace",
            fontWeight: 'bold',
            width: '100%',
            transition: 'all 0.2s',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#330000';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = '#1a0a0a';
          }}
        >
          [ ACKNOWLEDGE & PROCEED ]
        </button>
        
        <div style={{ 
          fontSize: 8, 
          color: '#333333', 
          letterSpacing: 2, 
          fontFamily: "'Courier New', monospace",
          marginTop: 12,
          textAlign: 'center',
        }}>
          THIS MESSAGE CANNOT BE IGNORED
        </div>
      </div>
    </>
  );
}
