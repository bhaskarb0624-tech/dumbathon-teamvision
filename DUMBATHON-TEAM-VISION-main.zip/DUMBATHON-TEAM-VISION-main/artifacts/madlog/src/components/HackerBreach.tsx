import React, { useEffect, useState } from 'react';

interface Props {
  onComplete: () => void;
}

const lines = [
  '> UNAUTHORIZED ACCESS',
  '> SIGNAL INTERCEPTED...',
  '> HELLO SURVIVOR',
  '> WE SEE YOU',
  '> YOUR ENTRIES HAVE BEEN READ',
  '> SYSTEM MEMORY: COMPROMISED',
  '> ...probably nothing.',
];

export default function HackerBreach({ onComplete }: Props) {
  const [visibleLines, setVisibleLines] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let idx = 0;
    const interval = setInterval(() => {
      if (idx < lines.length) {
        setVisibleLines(prev => [...prev, lines[idx]]);
        idx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setDone(true);
          setTimeout(onComplete, 500);
        }, 1200);
      }
    }, 500);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: done ? 'rgba(0,0,0,0)' : '#0d0000',
        zIndex: 99999,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        transition: done ? 'background-color 0.5s' : 'none',
        fontFamily: "'Courier New', monospace",
      }}
    >
      {!done && (
        <>
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'repeating-linear-gradient(to bottom, rgba(255,0,0,0.03) 0px, rgba(255,0,0,0.03) 2px, transparent 2px, transparent 4px)',
              pointerEvents: 'none',
            }}
          />
          <div style={{ maxWidth: 600, padding: '0 24px', width: '100%' }}>
            <div
              style={{
                border: '2px solid #cc0000',
                padding: 32,
                backgroundColor: '#0a0000',
                boxShadow: '0 0 60px rgba(200,0,0,0.4)',
              }}
            >
              <p style={{ color: '#ff0000', fontSize: 11, letterSpacing: 4, marginBottom: 24, opacity: 0.7 }}>
                SYSTEM INTRUSION DETECTED — NODE_7741
              </p>
              <div style={{ minHeight: 200 }}>
                {visibleLines.map((line, i) => (
                  <p
                    key={i}
                    style={{
                      color: i === visibleLines.length - 1 ? '#ff3333' : '#cc4444',
                      fontSize: i >= 2 && i <= 3 ? 28 : 16,
                      fontWeight: 'bold',
                      letterSpacing: i >= 2 && i <= 3 ? 6 : 2,
                      margin: '8px 0',
                      animation: 'hacker-text 0.3s ease-out',
                      opacity: 1,
                    }}
                    className="glitch-text"
                    data-text={line}
                  >
                    {line}
                  </p>
                ))}
                {visibleLines.length < lines.length && (
                  <span style={{ color: '#cc0000', fontSize: 16 }} className="blink">█</span>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
