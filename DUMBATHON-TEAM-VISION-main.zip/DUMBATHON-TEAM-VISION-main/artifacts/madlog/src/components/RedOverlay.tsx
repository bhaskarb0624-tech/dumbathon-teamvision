import React from 'react';

interface Props {
  intensity: number;
}

export default function RedOverlay({ intensity }: Props) {
  if (intensity <= 0) return null;
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: `rgba(200, 0, 0, ${Math.min(intensity * 0.12, 0.25)})`,
        pointerEvents: 'none',
        zIndex: 9997,
        mixBlendMode: 'multiply',
        animation: intensity > 0.5 ? 'red-pulse 2s ease-in-out infinite' : 'none',
      }}
    />
  );
}
