import React from 'react';
import type { PopupData } from '../lib/chaos';

interface Props {
  popup: PopupData;
  onClose: (id: string) => void;
}

const modeColors = {
  paranoid: { border: '#cc0000', bg: '#0d0202', text: '#ff4444', glow: 'rgba(204,0,0,0.4)' },
  sarcastic: { border: '#cc6600', bg: '#0d0802', text: '#ff9933', glow: 'rgba(204,102,0,0.4)' },
  madness: { border: '#8800cc', bg: '#07020d', text: '#cc44ff', glow: 'rgba(136,0,204,0.5)' },
};

export default function ChaosPopup({ popup, onClose }: Props) {
  const colors = modeColors[popup.mode];

  return (
    <div
      className="popup-spawn"
      style={{
        position: 'fixed',
        left: Math.min(popup.x, window.innerWidth - 340),
        top: Math.min(popup.y, window.innerHeight - 160),
        width: 320,
        zIndex: 10000,
        border: `2px solid ${colors.border}`,
        backgroundColor: colors.bg,
        boxShadow: `0 0 20px ${colors.glow}, inset 0 0 20px ${colors.glow}`,
        fontFamily: "'Courier New', monospace",
        userSelect: 'none',
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '4px 8px',
          backgroundColor: colors.border,
          borderBottom: `1px solid ${colors.border}`,
        }}
      >
        <span style={{ color: '#fff', fontSize: '10px', fontWeight: 'bold', letterSpacing: '2px' }}>
          SYSTEM WARNING
        </span>
        <button
          onClick={() => onClose(popup.id)}
          style={{
            background: 'none',
            border: 'none',
            color: '#fff',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: 'bold',
            lineHeight: 1,
            padding: '0 2px',
          }}
        >
          ×
        </button>
      </div>
      <div style={{ padding: '12px 14px 14px' }}>
        <p
          style={{
            color: colors.text,
            fontSize: '13px',
            fontWeight: 'bold',
            letterSpacing: '0.5px',
            margin: 0,
            lineHeight: 1.4,
          }}
          className={popup.mode === 'madness' ? 'glitch-text' : ''}
          data-text={popup.message}
        >
          {popup.message}
        </p>
        <div style={{ marginTop: 8, fontSize: '9px', color: '#553333', letterSpacing: '1px' }}>
          GEN-{popup.generation} | {new Date().toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}
