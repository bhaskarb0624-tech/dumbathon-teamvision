import React, { useState, useEffect, useRef, useCallback } from 'react';
import ChaosPopup from '../components/ChaosPopup';
import HackerBreach from '../components/HackerBreach';
import SecretEnding from '../components/SecretEnding';
import CursorMadness from '../components/CursorMadness';
import RedOverlay from '../components/RedOverlay';
import StillAliveButton from '../components/StillAliveButton';
import ActionBlockingPopup from '../components/ActionBlockingPopup';
import {
  getEntries,
  addEntry,
  updateEntry,
  deleteEntry,
  getMemory,
  saveMemory,
  corruptEntries,
  saveAutoSave,
  getAutoSave,
  clearAutoSave,
  addAutoSaveSnapshot,
  getRecoverableContent,
  type JournalEntry,
  type AutoSaveData,
} from '../lib/storage';
import {
  type MadnessStage,
  type PopupData,
  getPopupMode,
  getMessageForMode,
  getMemoryMessage,
  detectKeywords,
  getCorruptedWaterText,
  KEYWORD_RESPONSES,
  getPopupInterval,
  randomPosition,
  generatePopupId,
} from '../lib/chaos';
import { playStaticNoise, playDistortedBeep, playWhisper, playScreech } from '../lib/audio';
import { playMetallicScreech, playDeepRumble, playGlitch, playSiren, playHeartbeat } from '../lib/audio-horror';
import { playAlarm, playDemonicVoice, playExplosion, playScream, playChaosNoise } from '../lib/audio-extreme';

type View = 'write' | 'entries' | 'edit';

export default function MadlogApp() {
  const [stage, setStage] = useState<MadnessStage>(1);
  const [popups, setPopups] = useState<PopupData[]>([]);
  const [view, setView] = useState<View>('write');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [editEntry, setEditEntry] = useState<JournalEntry | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [showBreach, setShowBreach] = useState(false);
  const [showEnding, setShowEnding] = useState(false);
  const [shaking, setShaking] = useState(false);
  const [screenFlicker, setScreenFlicker] = useState(false);
  const [statusMsg, setStatusMsg] = useState('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE');
  const [keywordAlert, setKeywordAlert] = useState('');
  const [redIntensity, setRedIntensity] = useState(0);
  const [closedTotal, setClosedTotal] = useState(0);
  const [showStillAlive, setShowStillAlive] = useState(false);
  const [stillAliveTimer, setStillAliveTimer] = useState(60);
  const [lastAliveConfirm, setLastAliveConfirm] = useState(Date.now());
  const [contentBeforeDelete, setContentBeforeDelete] = useState('');
  const [showRecoveryNotice, setShowRecoveryNotice] = useState(false);
  const [actionBlockingPopup, setActionBlockingPopup] = useState<{ message: string; action: () => void } | null>(null);
  const memory = useRef(getMemory());
  const popupTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sessionStartRef = useRef(Date.now());
  const stillAliveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoSaveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setEntries(getEntries());
    const mem = getMemory();
    memory.current = mem;
    if (!mem.sessionStart) {
      mem.sessionStart = Date.now();
      saveMemory(mem);
    }
    sessionStartRef.current = mem.sessionStart || Date.now();
    localStorage.setItem('madlog_session_start', String(sessionStartRef.current));
    
    // Initialize "Still Alive" system
    setLastAliveConfirm(Date.now());
    startStillAliveTimer();
    startAutoSave();
    
    return () => {
      if (stillAliveIntervalRef.current) clearInterval(stillAliveIntervalRef.current);
      if (autoSaveIntervalRef.current) clearInterval(autoSaveIntervalRef.current);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    };
  }, []);

  // Stage progression based on time - FAST for prototype demo
  useEffect(() => {
    const timers = [
      setTimeout(() => setStage(2), 15000),  // 15 seconds
      setTimeout(() => setStage(3), 30000),  // 30 seconds
      setTimeout(() => setStage(4), 45000),  // 45 seconds
      setTimeout(() => {
        // Secret ending trigger at 50 seconds
        if (!memory.current.endingTriggered) {
          console.log('Auto-triggering secret ending at 50 seconds');
          const m = memory.current;
          m.endingTriggered = true;
          memory.current = m;
          saveMemory(m);
          setShowEnding(true);
        }
      }, 50000), // 50 seconds
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  // Stage effects
  useEffect(() => {
    if (stage >= 3) {
      setShaking(true);
      setRedIntensity(stage === 3 ? 0.5 : 1.0);
      // Deep rumble for stage 3+
      playDeepRumble();
    }
    if (stage >= 2) {
      schedulePopup();
      // Heartbeat for stage 2+
      playHeartbeat();
    }
    if (stage === 4) {
      const breachTimer = setTimeout(() => {
        triggerBreach();
      }, 5000);
      return () => clearTimeout(breachTimer);
    }
  }, [stage]);

  const schedulePopup = useCallback(() => {
    if (popupTimerRef.current) clearTimeout(popupTimerRef.current);
    const interval = getPopupInterval(stage);
    popupTimerRef.current = setTimeout(() => {
      spawnPopup(1, 0);
      schedulePopup();
    }, interval);
  }, [stage]);

  useEffect(() => {
    if (stage >= 2) schedulePopup();
    return () => {
      if (popupTimerRef.current) clearTimeout(popupTimerRef.current);
    };
  }, [stage, schedulePopup]);

  // Screen flicker
  useEffect(() => {
    if (stage < 2) return;
    const flickerInterval = setInterval(() => {
      if (Math.random() < 0.2) {
        setScreenFlicker(true);
        setTimeout(() => setScreenFlicker(false), 100 + Math.random() * 100);
      }
    }, 3000 + Math.random() * 5000);
    return () => clearInterval(flickerInterval);
  }, [stage]);

  // Random ambient horror sounds
  useEffect(() => {
    if (stage < 2) return;
    const ambientInterval = setInterval(() => {
      if (Math.random() < 0.3) {
        const ambientSounds = stage >= 4 
          ? [playScream, playDemonicVoice, playExplosion, playAlarm]
          : stage >= 3
          ? [playMetallicScreech, playGlitch, playDeepRumble, playScreech]
          : [playWhisper, playStaticNoise];
        
        const randomSound = ambientSounds[Math.floor(Math.random() * ambientSounds.length)];
        randomSound();
      }
    }, 15000 + Math.random() * 20000);
    return () => clearInterval(ambientInterval);
  }, [stage]);

  function spawnPopup(count: number, generation: number) {
    const mem = memory.current;
    const newPopups: PopupData[] = [];

    for (let i = 0; i < count; i++) {
      const mode = getPopupMode(stage);
      let message: string;

      // Sometimes use memory-based message
      if (Math.random() < 0.25 && mem.entriesWritten > 0) {
        message = getMemoryMessage(mem.entriesWritten, mem.popupsClosed, mem.keywordsFound);
      } else {
        message = getMessageForMode(mode);
      }

      const pos = randomPosition();
      newPopups.push({
        id: generatePopupId(),
        message,
        mode,
        x: Math.max(10, pos.x),
        y: Math.max(10, pos.y),
        generation,
      });
    }

    setPopups(prev => [...prev, ...newPopups]);

    // Different sounds based on stage
    if (stage >= 4) {
      const extremeSounds = [playScream, playAlarm, playExplosion, playChaosNoise];
      extremeSounds[Math.floor(Math.random() * extremeSounds.length)]();
    } else if (stage >= 3) {
      const horrorSounds = [playMetallicScreech, playGlitch, playSiren, playScreech];
      horrorSounds[Math.floor(Math.random() * horrorSounds.length)]();
    } else if (stage >= 2) {
      playStaticNoise(0.4, 0.6);
    }
  }

  function handleClosePopup(id: string) {
    setPopups(prev => prev.filter(p => p.id !== id));

    const mem = memory.current;
    mem.popupsClosed++;
    memory.current = mem;
    saveMemory(mem);
    setClosedTotal(mem.popupsClosed);

    // Virus multiplication — close 1, spawn more
    if (stage >= 2 && closedTotal > 0) {
      const closedSoFar = closedTotal;
      const gen = Math.min(Math.floor(Math.log2(closedSoFar + 1)) + 1, 6);
      const spawnCount = Math.min(gen + 1, 8);

      setTimeout(() => {
        spawnPopup(spawnCount, gen);
      }, 200);
    }

    // Louder, weirder sounds on close
    if (stage >= 4) {
      playGlitch();
    } else if (stage >= 3) {
      playDistortedBeep(300 + Math.random() * 400, 0.15);
    } else {
      playDistortedBeep(300 + Math.random() * 200, 0.1);
    }
  }

  function handlePanicClose() {
    setPopups([]);
    playExplosion();
    setStatusMsg('⚠ PANIC BUTTON ACTIVATED — THEY SAW THAT');
    setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 3000);
  }

  function triggerBreach() {
    if (memory.current.breachTriggered) return;
    const mem = memory.current;
    mem.breachTriggered = true;
    memory.current = mem;
    saveMemory(mem);
    playDemonicVoice();
    playAlarm();
    setTimeout(() => playScream(), 500);
    setShowBreach(true);
  }

  function handleBreachComplete() {
    setShowBreach(false);
    setStatusMsg('...probably nothing.');
    setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 5000);
  }

  function handleEndingComplete() {
    console.log('Secret ending completed - corrupting entries');
    setShowEnding(false);
    
    // Clear current content
    setContent('');
    setTitle('');
    
    // Corrupt all saved entries
    corruptEntries();
    setEntries(getEntries());
    setStatusMsg('⚠ MEMORY REWRITTEN');
    
    console.log('Entries after corruption:', getEntries());
  }

  function handleSaveEntry() {
    executeWithPopup('SAVE ENTRY', () => {
      if (!content.trim()) {
        setKeywordAlert('⚠ Entry cannot be empty. Or can it?');
        return;
      }

      const keywords = detectKeywords(content);
      let savedContent = content;

      // Silent water corruption
      if (keywords.includes('water')) {
        savedContent = getCorruptedWaterText(savedContent);
      }

      const entry: JournalEntry = {
        id: generatePopupId(),
        title: title.trim() || `Entry_${Date.now()}`,
        content: savedContent,
        timestamp: Date.now(),
      };

      addEntry(entry);
      setEntries(getEntries());

      const mem = memory.current;
      mem.entriesWritten++;
      keywords.forEach(kw => {
        if (!mem.keywordsFound.includes(kw)) mem.keywordsFound.push(kw);
      });
      memory.current = mem;
      saveMemory(mem);

      setTitle('');
      setContent('');
      clearAutoSave(); // Clear auto-save after successful save
      setStatusMsg('⚠ Entry saved. Being analyzed...');

      setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 3000);

      // Keyword popup responses
      keywords.forEach(kw => {
        const response = KEYWORD_RESPONSES[kw];
        if (response) {
          setTimeout(() => {
            setKeywordAlert(response);
            playWhisper();
            const pos = randomPosition();
            setPopups(prev => [
              ...prev,
              {
                id: generatePopupId(),
                message: response,
                mode: 'paranoid',
                x: pos.x,
                y: pos.y,
                generation: 0,
              },
            ]);
            setTimeout(() => setKeywordAlert(''), 4000);
          }, 800 + Math.random() * 1200);
        }
      });

      // Stage advancement from entries
      if (mem.entriesWritten >= 3 && stage === 1) setStage(2);
      if (mem.entriesWritten >= 5 && stage === 2) setStage(3);

      // Secret ending check - 50 seconds instead of 5 minutes
      const elapsed = Date.now() - sessionStartRef.current;
      if (elapsed > 50000 && !memory.current.endingTriggered) {
        const m = memory.current;
        m.endingTriggered = true;
        memory.current = m;
        saveMemory(m);
        setTimeout(() => setShowEnding(true), 3000);
      }
    });
  }

  function handleStartEdit(entry: JournalEntry) {
    executeWithPopup('EDIT ENTRY', () => {
      setEditEntry(entry);
      setEditTitle(entry.title);
      setEditContent(entry.content);
      setView('edit');
    });
  }

  function handleSaveEdit() {
    executeWithPopup('SAVE CHANGES', () => {
      if (!editEntry) return;
      updateEntry(editEntry.id, { title: editTitle, content: editContent });
      setEntries(getEntries());
      setView('entries');
      setEditEntry(null);
    });
  }

  function handleDeleteEntry(id: string) {
    executeWithPopup('DELETE ENTRY', () => {
      deleteEntry(id);
      setEntries(getEntries());
    });
  }

  // Still Alive System
  function startStillAliveTimer() {
    if (stillAliveIntervalRef.current) clearInterval(stillAliveIntervalRef.current);
    
    stillAliveIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - lastAliveConfirm;
      
      // Show button at 20 seconds
      if (elapsed >= 20000 && elapsed < 25000 && !showStillAlive) {
        console.log('Showing Still Alive button at', elapsed, 'ms');
        setShowStillAlive(true);
        playStaticNoise(0.3, 0.1);
      }
      
      // Timeout at 25 seconds
      if (elapsed >= 25000) {
        if (showStillAlive) {
          console.log('Still Alive timeout triggered at', elapsed, 'ms');
          handleStillAliveTimeout();
        }
      }
    }, 1000);
  }

  function startAutoSave() {
    if (autoSaveIntervalRef.current) clearInterval(autoSaveIntervalRef.current);
    
    // Auto-save every 5 seconds (faster for demo)
    autoSaveIntervalRef.current = setInterval(() => {
      if (content.trim()) {
        addAutoSaveSnapshot(content);
      }
    }, 5000);
  }

  function handleStillAliveConfirm() {
    console.log('Still Alive confirmed');
    setShowStillAlive(false);
    setLastAliveConfirm(Date.now());
    setStillAliveTimer(25); // Reset to 25 seconds total
    playDistortedBeep(400, 0.15);
    if (stage >= 3) playGlitch();
    setStatusMsg('⚠ PRESENCE CONFIRMED — MONITORING CONTINUES');
    setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 3000);
  }

  function handleStillAliveTimeout() {
    console.log('handleStillAliveTimeout called - content before:', content.length, 'chars');
    setShowStillAlive(false);
    
    // Save content before deletion for recovery
    setContentBeforeDelete(content);
    
    // Delete last 20 seconds of typing (instead of 60)
    const autoSave = getAutoSave();
    console.log('AutoSave data:', autoSave);
    
    if (autoSave && autoSave.snapshots.length > 0) {
      // Find snapshot from 20+ seconds ago
      const now = Date.now();
      const validSnapshot = autoSave.snapshots
        .filter(s => now - s.timestamp > 20000)
        .pop();
      
      console.log('Valid snapshot found:', validSnapshot);
      
      if (validSnapshot) {
        setContent(validSnapshot.content);
        console.log('Content restored to:', validSnapshot.content.length, 'chars');
        setShowRecoveryNotice(true);
        setTimeout(() => setShowRecoveryNotice(false), 5000);
      } else {
        // No valid snapshot, clear all content
        console.log('No valid snapshot - clearing all content');
        setContent('');
      }
    } else {
      console.log('No autosave data - clearing all content');
      setContent('');
    }
    
    // LOUD warning sounds
    playAlarm();
    setTimeout(() => playStaticNoise(0.6, 0.8), 300);
    if (stage >= 3) {
      setTimeout(() => playScream(), 600);
    }
    
    setStatusMsg('⚠ PRESENCE NOT CONFIRMED — DATA PURGED');
    setLastAliveConfirm(Date.now());
    setStillAliveTimer(25); // Reset to 25 seconds total
    
    setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 4000);
  }

  function handleRecoverContent() {
    if (contentBeforeDelete) {
      setContent(contentBeforeDelete);
      setContentBeforeDelete('');
      setShowRecoveryNotice(false);
      setStatusMsg('⚠ DATA RECOVERED FROM BACKUP');
      setTimeout(() => setStatusMsg('MADLOG v1.0 — SURVIVOR JOURNAL SYSTEM ONLINE'), 3000);
    }
  }

  // Action blocking popup system
  function executeWithPopup(actionName: string, action: () => void) {
    if (stage >= 2 && Math.random() < 0.7) {
      // Show blocking popup with sound
      setActionBlockingPopup({ message: actionName, action });
      if (stage >= 4) {
        playChaosNoise();
      } else if (stage >= 3) {
        playSiren();
      } else {
        playStaticNoise(0.4, 0.6);
      }
    } else {
      // Execute immediately
      action();
    }
  }

  function handlePopupDismiss() {
    if (actionBlockingPopup) {
      actionBlockingPopup.action();
      setActionBlockingPopup(null);
    }
  }

  // Update content handler to track typing
  function handleContentChange(newContent: string) {
    setContent(newContent);
    
    // Update auto-save title
    const autoSave = getAutoSave();
    if (autoSave) {
      autoSave.title = title;
      saveAutoSave(autoSave);
    } else {
      saveAutoSave({
        content: newContent,
        title,
        timestamp: Date.now(),
        snapshots: [],
      });
    }
    
    // Debounced snapshot
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      if (newContent.trim()) {
        addAutoSaveSnapshot(newContent);
      }
    }, 3000);
  }

  const containerClass = stage >= 4 ? 'heavy-shake' : stage >= 3 ? (shaking ? 'shake' : '') : '';

  return (
    <div
      className={`scan-overlay min-h-screen ${containerClass}`}
      style={{
        backgroundColor: '#090909',
        color: '#7a967a',
        fontFamily: "'Courier New', Courier, monospace",
        opacity: screenFlicker ? 0.88 : 1,
        transition: screenFlicker ? 'none' : 'opacity 0.05s',
      }}
    >
      <RedOverlay intensity={redIntensity} />
      <CursorMadness stage={stage} />

      {/* Header */}
      <div
        style={{
          borderBottom: `1px solid ${stage >= 3 ? '#440000' : '#1a2a1a'}`,
          padding: '12px 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: '#050505',
        }}
      >
        <div>
          <h1
            style={{
              fontSize: 20,
              fontWeight: 'bold',
              color: stage >= 3 ? '#cc3333' : '#4a7a4a',
              letterSpacing: 6,
              margin: 0,
            }}
            className={stage >= 4 ? 'glitch-text' : stage >= 3 ? 'flicker' : ''}
            data-text="MADLOG"
          >
            MADLOG
          </h1>
          <p style={{ fontSize: 9, color: '#2a4a2a', letterSpacing: 3, margin: '2px 0 0' }}>
            CORRUPTED SURVIVOR JOURNAL
          </p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <p style={{ fontSize: 9, color: '#334433', letterSpacing: 2, margin: 0 }}>
            STAGE: {stage} / 4
          </p>
          <p style={{ fontSize: 9, color: stage >= 2 ? '#cc3333' : '#334433', letterSpacing: 2, margin: '2px 0 0' }}>
            {stage === 1 ? 'NORMAL' : stage === 2 ? 'PARANOID' : stage === 3 ? 'SARCASTIC' : 'INSANITY'}
          </p>
        </div>
      </div>

      {/* Status bar */}
      <div
        style={{
          backgroundColor: '#040404',
          borderBottom: `1px solid #111811`,
          padding: '4px 24px',
          fontSize: 10,
          color: '#334433',
          letterSpacing: 2,
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <span className={stage >= 3 ? 'flicker' : ''}>{statusMsg}</span>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          {stage >= 2 && (
            <span 
              style={{ 
                color: stillAliveTimer < 5 ? '#cc0000' : stillAliveTimer < 10 ? '#cc6600' : '#334433',
                fontWeight: stillAliveTimer < 10 ? 'bold' : 'normal',
              }}
              className={stillAliveTimer < 5 ? 'blink' : ''}
            >
              {showStillAlive ? `⚠ CONFIRM PRESENCE: ${Math.max(0, 5 - Math.floor((Date.now() - lastAliveConfirm - 20000) / 1000))}s` : `NEXT CHECK: ${Math.max(0, 20 - Math.floor((Date.now() - lastAliveConfirm) / 1000))}s`}
            </span>
          )}
          <span>{new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Nav */}
      <div
        style={{
          backgroundColor: '#060606',
          borderBottom: `1px solid #111811`,
          padding: '0 24px',
          display: 'flex',
          gap: 0,
        }}
      >
        {(['write', 'entries'] as View[]).map(v => (
          <button
            key={v}
            onClick={() => setView(v)}
            style={{
              background: view === v ? '#0d150d' : 'transparent',
              border: 'none',
              borderBottom: view === v ? '1px solid #4a7a4a' : '1px solid transparent',
              color: view === v ? '#5a8a5a' : '#334433',
              padding: '8px 20px',
              cursor: 'pointer',
              fontSize: 11,
              letterSpacing: 3,
              fontFamily: "'Courier New', monospace",
              textTransform: 'uppercase',
            }}
          >
            {v === 'write' ? '[ WRITE ]' : `[ VIEW ENTRIES: ${entries.length} ]`}
          </button>
        ))}

        {/* Panic button — hidden */}
        <button
          onClick={handlePanicClose}
          title="PANIC"
          style={{
            marginLeft: 'auto',
            background: 'transparent',
            border: 'none',
            color: '#1a0a0a',
            padding: '8px 6px',
            cursor: 'pointer',
            fontSize: 8,
            fontFamily: "'Courier New', monospace",
            letterSpacing: 1,
          }}
        >
          ·
        </button>
      </div>

      {/* Main content */}
      <div style={{ maxWidth: 720, margin: '0 auto', padding: '24px 24px' }}>
        {view === 'write' && (
          <div>
            {keywordAlert && (
              <div
                style={{
                  border: '1px solid #cc3333',
                  backgroundColor: '#0d0303',
                  padding: '8px 14px',
                  marginBottom: 16,
                  fontSize: 12,
                  color: '#cc3333',
                  letterSpacing: 1,
                  animation: 'popup-spawn 0.3s ease-out',
                }}
              >
                {keywordAlert}
              </div>
            )}

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 9, letterSpacing: 3, color: '#334433', marginBottom: 6 }}>
                ENTRY TITLE:
              </label>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="Day ??? - Unknown location..."
                style={{
                  width: '100%',
                  backgroundColor: '#070d07',
                  border: `1px solid ${stage >= 3 ? '#330000' : '#1a2a1a'}`,
                  color: '#8a9e8a',
                  padding: '8px 12px',
                  fontSize: 13,
                  fontFamily: "'Courier New', monospace",
                  outline: 'none',
                  letterSpacing: 1,
                }}
              />
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 9, letterSpacing: 3, color: '#334433', marginBottom: 6 }}>
                JOURNAL ENTRY:
              </label>
              <textarea
                value={content}
                onChange={e => handleContentChange(e.target.value)}
                placeholder="Write your survival log here... (they are watching)"
                rows={10}
                style={{
                  width: '100%',
                  backgroundColor: '#060c06',
                  border: `1px solid ${stage >= 3 ? '#330000' : '#1a2a1a'}`,
                  color: '#7a967a',
                  padding: '12px',
                  fontSize: 13,
                  fontFamily: "'Courier New', monospace",
                  outline: 'none',
                  lineHeight: 1.7,
                  letterSpacing: 0.5,
                }}
              />
            </div>

            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <button
                onClick={handleSaveEntry}
                style={{
                  backgroundColor: '#0a1a0a',
                  border: `1px solid ${stage >= 3 ? '#cc3333' : '#2a4a2a'}`,
                  color: stage >= 3 ? '#cc3333' : '#5a8a5a',
                  padding: '10px 24px',
                  cursor: 'pointer',
                  fontSize: 11,
                  letterSpacing: 3,
                  fontFamily: "'Courier New', monospace',",
                }}
              >
                [ SAVE ENTRY ]
              </button>

              <span style={{ fontSize: 9, color: '#1a2a1a', letterSpacing: 2 }}>
                {content.length} chars recorded
              </span>
            </div>

            {stage >= 2 && (
              <div style={{ marginTop: 24, padding: '12px', backgroundColor: '#060606', border: '1px solid #110a0a' }}>
                <p style={{ fontSize: 9, color: '#331a1a', letterSpacing: 2, margin: 0 }}>
                  ⚠ THIS SESSION IS BEING MONITORED — ENTRIES: {memory.current.entriesWritten} — KEYWORDS DETECTED: {memory.current.keywordsFound.length}
                </p>
              </div>
            )}
          </div>
        )}

        {view === 'entries' && (
          <div>
            <h2 style={{ fontSize: 12, letterSpacing: 4, color: '#334433', marginBottom: 16, fontWeight: 'normal' }}>
              PREVIOUS ENTRIES
              {entries.some(e => e.corrupted) && (
                <span style={{ color: '#cc3333', marginLeft: 16 }}>⚠ MEMORY CORRUPTION DETECTED</span>
              )}
            </h2>

            {entries.length === 0 && (
              <p style={{ color: '#1a2a1a', fontSize: 12, letterSpacing: 2 }}>
                No entries found. They may have been deleted. Or you never wrote any.
              </p>
            )}

            {entries.map(entry => (
              <div
                key={entry.id}
                style={{
                  border: `1px solid ${entry.corrupted ? '#440000' : '#0f1f0f'}`,
                  backgroundColor: entry.corrupted ? '#0a0404' : '#060c06',
                  padding: '16px',
                  marginBottom: 12,
                  transition: 'border-color 0.3s',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div>
                    <h3
                      style={{
                        fontSize: 13,
                        fontWeight: 'bold',
                        color: entry.corrupted ? '#993333' : '#5a8a5a',
                        margin: 0,
                        letterSpacing: 1,
                      }}
                    >
                      {entry.title}
                    </h3>
                    <p style={{ fontSize: 9, color: '#1a2a1a', margin: '4px 0 0', letterSpacing: 2 }}>
                      {new Date(entry.timestamp).toLocaleString()}
                      {entry.corrupted && ' — [CORRUPTED]'}
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {!entry.corrupted && (
                      <button
                        onClick={() => handleStartEdit(entry)}
                        style={{
                          background: 'transparent',
                          border: '1px solid #1a2a1a',
                          color: '#334433',
                          padding: '4px 10px',
                          cursor: 'pointer',
                          fontSize: 9,
                          letterSpacing: 2,
                          fontFamily: "'Courier New', monospace",
                        }}
                      >
                        EDIT
                      </button>
                    )}
                    <button
                      onClick={() => handleDeleteEntry(entry.id)}
                      style={{
                        background: 'transparent',
                        border: '1px solid #330000',
                        color: '#440000',
                        padding: '4px 10px',
                        cursor: 'pointer',
                        fontSize: 9,
                        letterSpacing: 2,
                        fontFamily: "'Courier New', monospace",
                      }}
                    >
                      DEL
                    </button>
                  </div>
                </div>
                <p
                  style={{
                    fontSize: 12,
                    color: entry.corrupted ? '#662222' : '#5a7a5a',
                    lineHeight: 1.7,
                    margin: 0,
                    whiteSpace: 'pre-wrap',
                  }}
                >
                  {entry.content.length > 200 ? entry.content.slice(0, 200) + '...' : entry.content}
                </p>
              </div>
            ))}
          </div>
        )}

        {view === 'edit' && editEntry && (
          <div>
            <h2 style={{ fontSize: 12, letterSpacing: 4, color: '#334433', marginBottom: 16, fontWeight: 'normal' }}>
              EDITING ENTRY
            </h2>

            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 9, letterSpacing: 3, color: '#334433', marginBottom: 6 }}>
                TITLE:
              </label>
              <input
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                style={{
                  width: '100%',
                  backgroundColor: '#070d07',
                  border: '1px solid #1a2a1a',
                  color: '#8a9e8a',
                  padding: '8px 12px',
                  fontSize: 13,
                  fontFamily: "'Courier New', monospace",
                  outline: 'none',
                }}
              />
            </div>

            <div style={{ marginBottom: 16 }}>
              <textarea
                value={editContent}
                onChange={e => setEditContent(e.target.value)}
                rows={10}
                style={{
                  width: '100%',
                  backgroundColor: '#060c06',
                  border: '1px solid #1a2a1a',
                  color: '#7a967a',
                  padding: '12px',
                  fontSize: 13,
                  fontFamily: "'Courier New', monospace",
                  outline: 'none',
                  lineHeight: 1.7,
                }}
              />
            </div>

            <div style={{ display: 'flex', gap: 12 }}>
              <button
                onClick={handleSaveEdit}
                style={{
                  backgroundColor: '#0a1a0a',
                  border: '1px solid #2a4a2a',
                  color: '#5a8a5a',
                  padding: '10px 24px',
                  cursor: 'pointer',
                  fontSize: 11,
                  letterSpacing: 3,
                  fontFamily: "'Courier New', monospace",
                }}
              >
                [ SAVE CHANGES ]
              </button>
              <button
                onClick={() => { setView('entries'); setEditEntry(null); }}
                style={{
                  backgroundColor: 'transparent',
                  border: '1px solid #1a1a1a',
                  color: '#334433',
                  padding: '10px 24px',
                  cursor: 'pointer',
                  fontSize: 11,
                  letterSpacing: 3,
                  fontFamily: "'Courier New', monospace",
                }}
              >
                [ CANCEL ]
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Chaos Popups */}
      {popups.map(popup => (
        <ChaosPopup key={popup.id} popup={popup} onClose={handleClosePopup} />
      ))}

      {/* Still Alive Button */}
      {showStillAlive && (Date.now() - lastAliveConfirm) < 25000 && (
        <StillAliveButton 
          onConfirm={handleStillAliveConfirm} 
          timeRemaining={Math.max(0, 5 - Math.floor((Date.now() - lastAliveConfirm - 20000) / 1000))} 
        />
      )}

      {/* Recovery Notice */}
      {showRecoveryNotice && contentBeforeDelete && (
        <div
          style={{
            position: 'fixed',
            top: 20,
            right: 20,
            zIndex: 10001,
            backgroundColor: '#0a1a0a',
            border: '2px solid #cc6600',
            padding: '16px 20px',
            maxWidth: 350,
            boxShadow: '0 0 20px rgba(204, 102, 0, 0.5)',
          }}
        >
          <div style={{ 
            fontSize: 10, 
            color: '#ff9933', 
            letterSpacing: 3, 
            fontFamily: "'Courier New', monospace",
            marginBottom: 8,
            fontWeight: 'bold',
          }}>
            ⚠ DATA RECOVERY AVAILABLE
          </div>
          <div style={{ 
            fontSize: 11, 
            color: '#cc9966', 
            letterSpacing: 1, 
            fontFamily: "'Courier New', monospace",
            marginBottom: 12,
            lineHeight: 1.5,
          }}>
            Backup detected. Content can be restored.
          </div>
          <button
            onClick={handleRecoverContent}
            style={{
              backgroundColor: '#1a0a00',
              border: '2px solid #cc6600',
              color: '#ff9933',
              padding: '8px 16px',
              cursor: 'pointer',
              fontSize: 11,
              letterSpacing: 2,
              fontFamily: "'Courier New', monospace",
              fontWeight: 'bold',
              width: '100%',
            }}
          >
            [ RECOVER DATA ]
          </button>
        </div>
      )}

      {/* Action Blocking Popup */}
      {actionBlockingPopup && (
        <ActionBlockingPopup 
          message={actionBlockingPopup.message} 
          onDismiss={handlePopupDismiss} 
        />
      )}

      {/* Hacker Breach */}
      {showBreach && <HackerBreach onComplete={handleBreachComplete} />}

      {/* Secret Ending */}
      {showEnding && <SecretEnding onComplete={handleEndingComplete} />}
      
      {/* Debug: Manual secret ending trigger */}
      {stage >= 4 && (
        <button
          onClick={() => {
            console.log('Manual secret ending trigger');
            setShowEnding(true);
          }}
          style={{
            position: 'fixed',
            bottom: 10,
            left: 10,
            background: '#330000',
            border: '1px solid #cc0000',
            color: '#cc0000',
            padding: '4px 8px',
            fontSize: 8,
            fontFamily: "'Courier New', monospace",
            cursor: 'pointer',
            zIndex: 9999,
          }}
        >
          [DEBUG: TRIGGER ENDING]
        </button>
      )}

      {/* Footer */}
      <div
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          padding: '4px 24px',
          backgroundColor: '#040404',
          borderTop: '1px solid #0d0d0d',
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: 9,
          color: '#1a2a1a',
          letterSpacing: 2,
          zIndex: 9990,
        }}
      >
        <span>SESSION: {Math.floor((Date.now() - sessionStartRef.current) / 1000)}s</span>
        <span>ENTRIES: {memory.current.entriesWritten}</span>
        <span className={stage >= 3 ? 'blink' : ''}>
          {stage >= 2 ? `⚠ MONITORED` : 'SECURE'}
        </span>
        <span>POPUPS CLOSED: {closedTotal}</span>
      </div>
    </div>
  );
}
