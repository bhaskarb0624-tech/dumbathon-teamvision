// EXTREME HORROR SOUNDS - VERY LOUD AND DISTURBING

let audioCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

// Ear-piercing alarm
export function playAlarm(): void {
  try {
    const ctx = getAudioCtx();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = 'square';
    osc2.type = 'square';
    osc1.frequency.value = 1000;
    osc2.frequency.value = 1200;

    gainNode.gain.setValueAtTime(0.8, ctx.currentTime);
    gainNode.gain.setValueAtTime(0, ctx.currentTime + 0.1);
    gainNode.gain.setValueAtTime(0.8, ctx.currentTime + 0.2);
    gainNode.gain.setValueAtTime(0, ctx.currentTime + 0.3);
    gainNode.gain.setValueAtTime(0.8, ctx.currentTime + 0.4);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + 0.6);
    osc2.stop(ctx.currentTime + 0.6);
  } catch {}
}

// Demonic voice effect
export function playDemonicVoice(): void {
  try {
    const ctx = getAudioCtx();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const osc3 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const distortion = ctx.createWaveShaper();

    const curve = new Float32Array(1024);
    for (let i = 0; i < 1024; i++) {
      const x = (i * 2) / 1024 - 1;
      curve[i] = Math.tanh(x * 10);
    }
    distortion.curve = curve;

    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc3.type = 'triangle';
    
    osc1.frequency.setValueAtTime(80, ctx.currentTime);
    osc1.frequency.linearRampToValueAtTime(40, ctx.currentTime + 1.5);
    
    osc2.frequency.setValueAtTime(160, ctx.currentTime);
    osc2.frequency.linearRampToValueAtTime(80, ctx.currentTime + 1.5);
    
    osc3.frequency.setValueAtTime(240, ctx.currentTime);
    osc3.frequency.linearRampToValueAtTime(120, ctx.currentTime + 1.5);

    gainNode.gain.setValueAtTime(0.7, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);

    osc1.connect(distortion);
    osc2.connect(distortion);
    osc3.connect(distortion);
    distortion.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start();
    osc2.start();
    osc3.start();
    osc1.stop(ctx.currentTime + 1.5);
    osc2.stop(ctx.currentTime + 1.5);
    osc3.stop(ctx.currentTime + 1.5);
  } catch {}
}

// Explosion sound
export function playExplosion(): void {
  try {
    const ctx = getAudioCtx();
    const bufferSize = ctx.sampleRate * 0.8;
    const buffer = ctx.createBuffer(2, bufferSize, ctx.sampleRate);
    const dataL = buffer.getChannelData(0);
    const dataR = buffer.getChannelData(1);

    for (let i = 0; i < bufferSize; i++) {
      const decay = 1 - (i / bufferSize);
      dataL[i] = (Math.random() * 2 - 1) * decay;
      dataR[i] = (Math.random() * 2 - 1) * decay;
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(8000, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.8);
    
    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0.9, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);

    source.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);
    source.start();
  } catch {}
}

// Distorted scream
export function playScream(): void {
  try {
    const ctx = getAudioCtx();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const osc3 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const distortion = ctx.createWaveShaper();

    const curve = new Float32Array(2048);
    for (let i = 0; i < 2048; i++) {
      const x = (i * 2) / 2048 - 1;
      curve[i] = Math.sign(x) * Math.pow(Math.abs(x), 0.3);
    }
    distortion.curve = curve;
    distortion.oversample = '4x';

    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc3.type = 'sawtooth';
    
    osc1.frequency.setValueAtTime(1200, ctx.currentTime);
    osc1.frequency.exponentialRampToValueAtTime(3000, ctx.currentTime + 0.7);
    
    osc2.frequency.setValueAtTime(1800, ctx.currentTime);
    osc2.frequency.exponentialRampToValueAtTime(4500, ctx.currentTime + 0.7);
    
    osc3.frequency.setValueAtTime(600, ctx.currentTime);
    osc3.frequency.exponentialRampToValueAtTime(1500, ctx.currentTime + 0.7);

    gainNode.gain.setValueAtTime(0.8, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.7);

    osc1.connect(distortion);
    osc2.connect(distortion);
    osc3.connect(distortion);
    distortion.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start();
    osc2.start();
    osc3.start();
    osc1.stop(ctx.currentTime + 0.7);
    osc2.stop(ctx.currentTime + 0.7);
    osc3.stop(ctx.currentTime + 0.7);
  } catch {}
}

// Random chaos sound - unpredictable
export function playChaosNoise(): void {
  try {
    const ctx = getAudioCtx();
    const sounds = [playAlarm, playScream, playExplosion, playDemonicVoice];
    const randomSound = sounds[Math.floor(Math.random() * sounds.length)];
    randomSound();
  } catch {}
}
