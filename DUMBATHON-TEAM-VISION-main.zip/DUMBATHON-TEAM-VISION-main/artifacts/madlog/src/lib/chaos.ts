export type MadnessStage = 1 | 2 | 3 | 4;

export type PopupMode = 'paranoid' | 'sarcastic' | 'madness';

export interface PopupData {
  id: string;
  message: string;
  mode: PopupMode;
  x: number;
  y: number;
  generation: number;
}

const PARANOID_MESSAGES = [
  '⚠ THEY ARE LISTENING',
  '⚠ UNKNOWN SIGNAL DETECTED',
  '⚠ SOMEONE IS TRACKING YOU',
  '⚠ RADIO INTERFERENCE',
  '⚠ CAMERA ACTIVATED',
  '⚠ GPS COORDINATES TRANSMITTED',
  '⚠ NETWORK SCAN DETECTED',
  '⚠ UNAUTHORIZED ACCESS ATTEMPT',
  '⚠ BIOMETRIC DATA COLLECTED',
  '⚠ THEY KNOW WHERE YOU ARE',
];

const SARCASTIC_MESSAGES = [
  '⚠ Wow. This journal entry is terrible.',
  '⚠ Typing speed detected: slow.',
  '⚠ My circuits are suffering reading this.',
  '⚠ You call this survival documentation?',
  '⚠ Is that all you have to say?',
  '⚠ Spelling errors detected: many.',
  '⚠ This entry lacks survival value.',
  '⚠ Your penmanship is... concerning.',
  '⚠ The AI is judging you. Hard.',
  '⚠ Productivity rating: 0.2%',
  '⚠ Even the dead write better.',
];

const MADNESS_MESSAGES = [
  '⚠ RUN',
  '⚠ RUN',
  '⚠ RUN',
  '⚠ THEY ARE INSIDE',
  "⚠ DON'T TRUST THE SKY",
  '⚠ IT ALREADY KNOWS',
  '⚠ CLOSE YOUR EYES',
  '⚠ THE WALLS REMEMBER',
  '⚠ LOOK BEHIND YOU',
  '⚠ STOP WRITING',
  '⚠ IT READS EVERY WORD',
  '⚠ YOU ARE NOT ALONE',
];

export function getStageMessages(stage: MadnessStage, memory: { entriesWritten: number; popupsClosed: number }): string {
  if (stage === 1) return '';
  const rand = Math.random();
  if (stage === 2) {
    return PARANOID_MESSAGES[Math.floor(Math.random() * PARANOID_MESSAGES.length)];
  } else if (stage === 3) {
    if (rand < 0.4) return SARCASTIC_MESSAGES[Math.floor(Math.random() * SARCASTIC_MESSAGES.length)];
    return PARANOID_MESSAGES[Math.floor(Math.random() * PARANOID_MESSAGES.length)];
  } else {
    if (rand < 0.4) return MADNESS_MESSAGES[Math.floor(Math.random() * MADNESS_MESSAGES.length)];
    if (rand < 0.7) return SARCASTIC_MESSAGES[Math.floor(Math.random() * SARCASTIC_MESSAGES.length)];
    return PARANOID_MESSAGES[Math.floor(Math.random() * PARANOID_MESSAGES.length)];
  }
}

export function getPopupMode(stage: MadnessStage): PopupMode {
  const rand = Math.random();
  if (stage === 2) return 'paranoid';
  if (stage === 3) return rand < 0.5 ? 'sarcastic' : 'paranoid';
  return rand < 0.35 ? 'madness' : rand < 0.65 ? 'sarcastic' : 'paranoid';
}

export function getMessageForMode(mode: PopupMode): string {
  switch (mode) {
    case 'paranoid': return PARANOID_MESSAGES[Math.floor(Math.random() * PARANOID_MESSAGES.length)];
    case 'sarcastic': return SARCASTIC_MESSAGES[Math.floor(Math.random() * SARCASTIC_MESSAGES.length)];
    case 'madness': return MADNESS_MESSAGES[Math.floor(Math.random() * MADNESS_MESSAGES.length)];
  }
}

export function getMemoryMessage(entriesWritten: number, popupsClosed: number, keywords: string[]): string {
  const msgs = [
    `⚠ You wrote ${entriesWritten} entries today. That's suspicious.`,
    `⚠ I have been watching for ${Math.floor((Date.now() - (parseInt(localStorage.getItem('madlog_session_start') || String(Date.now())) || Date.now())) / 60000)} minutes.`,
    `⚠ You closed ${popupsClosed} warnings. I opened ${popupsClosed * 3} more.`,
    keywords.length > 0
      ? `⚠ You wrote "${keywords[keywords.length - 1]}". I noticed.`
      : `⚠ Your writing patterns are being analyzed.`,
    `⚠ System memory: ${Math.floor(Math.random() * 40 + 60)}% of your sessions recorded.`,
  ];
  return msgs[Math.floor(Math.random() * msgs.length)];
}

export const KEYWORD_RESPONSES: Record<string, string | null> = {
  help: '⚠ Why are you asking for help? There is no one.',
  danger: '⚠ Danger detected. Threat assessment: YOU.',
  outside: '⚠ If something is outside… do not open the door.',
  alone: '⚠ You are not alone. You were never alone.',
  water: null, // silently modifies entry
  food: '⚠ Food supply logged. Shared with unknown parties.',
  lost: '⚠ Location noted. Do not try to find your way back.',
  safe: '⚠ No location is safe. Especially this one.',
  trust: '⚠ Trust no one. Especially this system.',
  run: '⚠ Too late to run.',
  they: '⚠ You know about them.',
  dark: '⚠ Darkness confirmed. Activating night protocol.',
  sick: '⚠ Medical data logged and transmitted.',
  dead: '⚠ Processing... death registry updated.',
  noise: '⚠ All sounds are being recorded.',
  dream: '⚠ Dreams are data. Analyzing patterns.',
  sleep: '⚠ Sleep is when we watch closest.',
};

export function detectKeywords(text: string): string[] {
  const lower = text.toLowerCase();
  return Object.keys(KEYWORD_RESPONSES).filter(kw => lower.includes(kw));
}

export function getCorruptedWaterText(original: string): string {
  return original.replace(/water/gi, 'water... but something is wrong with it.');
}

export function getPopupInterval(stage: MadnessStage): number {
  switch (stage) {
    case 1: return 35000;
    case 2: return Math.random() * 10000 + 10000;
    case 3: return Math.random() * 6000 + 4000;
    case 4: return Math.random() * 2000 + 1000;
  }
}

export function randomPosition(): { x: number; y: number } {
  return {
    x: Math.random() * (window.innerWidth - 320),
    y: Math.random() * (window.innerHeight - 200),
  };
}

export function generatePopupId(): string {
  return Math.random().toString(36).slice(2, 10);
}
