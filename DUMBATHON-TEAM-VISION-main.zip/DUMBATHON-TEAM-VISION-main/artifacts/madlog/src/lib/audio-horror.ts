// Additional horror sound effects - LOUD and WEIRD

let audioCtx: AudioContext | null = null;

function getAudioCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

// Metallic screech - like metal scraping
export function playMetallicScreech(): void {
  try {
    const ctx = getAudioCtx();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const osc3 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc3.type = 'triangle';
    
    osc1.frequency.setValueAtTime(1500, ctx.currentTime);
    osc1.frequency.linearRampToValueAtTime(6000, ctx.currentTime + 0.5);
    
    osc2.frequency.setValueAtTime(1503, ctx.currentTime);
    osc2.frequency.linearRampToValueAtTime(6100, ctx.currentTime + 0.5);
    
    osc3.frequency.setValueAtTime(750, ctx.currentTime);
    osc3.frequency.linearRampToValueAtTime(3000, ctx.currentTime + 0.5);

    filter.type = 'bandpass';
    filter.frequency.value = 3000;
    filter.Q.value = 10;

    gainNode.gain.setValueAtTime(0.7, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);

    osc1.connect(filter);
    osc2.connect(filter);
    osc3.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start();
    osc2.start();
    osc3.start();
    osc1.stop(ctx.currentTime + 0.5);
    osc2.stop(ctx.currentTime + 0.5);
    osc3.stop(ctx.currentTime + 0.5);
  } catch {}
}

// Deep rumble - like something approaching
export function playDeepRumble(): void {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(40, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(20, ctx.currentTime + 2);

    filter.type = 'lowpass';
    filter.frequency.value = 200;

    gainNode.gain.setValueAtTime(0.8, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 2);
  } catch {}
}

// Glitch sound - digital corruption
export function playGlitch(): void {
  try {
    const ctx = getAudioCtx();
    const bufferSize = ctx.sampleRate * 0.15;
    const buffer = ctx.createBuffer(2, bufferSize, ctx.sampleRate);
    const dataL = buffer.getChannelData(0);
    const dataR = buffer.getChannelData(1);

    for (let i = 0; i < bufferSize; i++) {
      const glitch = Math.floor(Math.random() * 10) === 0 ? 1 : 0;
      dataL[i] = glitch * (Math.random() * 2 - 1);
      dataR[i] = glitch * (Math.random() * 2 - 1);
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    const gainNode = ctx.createGain();
    gainNode.gain.value = 0.8;

    source.connect(gainNode);
    gainNode.connect(ctx.destination);
    source.start();
  } catch {}
}

// Siren - emergency alert
export function playSiren(): void {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = 'sine';
    
    // Oscillate between two frequencies
    for (let i = 0; i < 6; i++) {
      osc.frequency.setValueAtTime(800, ctx.currentTime + i * 0.5);
      osc.frequency.setValueAtTime(400, ctx.currentTime + i * 0.5 + 0.25);
    }

    gainNode.gain.setValueAtTime(0.6, ctx.currentTime);
    gainNode.gain.setValueAtTime(0.001, ctx.currentTime + 3);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 3);
  } catch {}
}

// Heartbeat - intense and fast
export function playHeartbeat(): void {
  try {
    const ctx = getAudioCtx();
    
    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        const osc = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.value = 60;
        
        gainNode.gain.setValueAtTime(0.5, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      }, i * 400);
    }
  } catch {}
}
