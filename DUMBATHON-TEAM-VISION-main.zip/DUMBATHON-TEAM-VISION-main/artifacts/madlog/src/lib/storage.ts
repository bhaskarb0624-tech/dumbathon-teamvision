export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  timestamp: number;
  corrupted?: boolean;
}

export interface SystemMemory {
  entriesWritten: number;
  sessionStart: number;
  keywordsFound: string[];
  totalTypingTime: number;
  lastTypingSpeed: number;
  popupsClosed: number;
  breachTriggered: boolean;
  endingTriggered: boolean;
}

export interface AutoSaveData {
  content: string;
  title: string;
  timestamp: number;
  snapshots: Array<{
    content: string;
    timestamp: number;
  }>;
}

export function getEntries(): JournalEntry[] {
  try {
    const raw = localStorage.getItem('madlog_entries');
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveEntries(entries: JournalEntry[]): void {
  localStorage.setItem('madlog_entries', JSON.stringify(entries));
}

export function addEntry(entry: JournalEntry): void {
  const entries = getEntries();
  entries.unshift(entry);
  saveEntries(entries);
}

export function updateEntry(id: string, updates: Partial<JournalEntry>): void {
  const entries = getEntries();
  const idx = entries.findIndex(e => e.id === id);
  if (idx !== -1) {
    entries[idx] = { ...entries[idx], ...updates };
    saveEntries(entries);
  }
}

export function deleteEntry(id: string): void {
  const entries = getEntries();
  saveEntries(entries.filter(e => e.id !== id));
}

export function getMemory(): SystemMemory {
  try {
    const raw = localStorage.getItem('madlog_memory');
    if (!raw) return createDefaultMemory();
    return JSON.parse(raw);
  } catch {
    return createDefaultMemory();
  }
}

function createDefaultMemory(): SystemMemory {
  return {
    entriesWritten: 0,
    sessionStart: Date.now(),
    keywordsFound: [],
    totalTypingTime: 0,
    lastTypingSpeed: 0,
    popupsClosed: 0,
    breachTriggered: false,
    endingTriggered: false,
  };
}

export function saveMemory(memory: SystemMemory): void {
  localStorage.setItem('madlog_memory', JSON.stringify(memory));
}

export function corruptEntries(): void {
  const entries = getEntries();
  const corruptedTexts = [
    "I don't remember writing this...",
    "THEY FOUND IT. THEY FOUND IT. THEY FOUND IT.",
    "[DATA CORRUPTED]",
    "why did i write this why did i write this why",
    "...........................",
    "The signal broke through. I couldn't stop it.",
    "I never wrote this. Someone else did.",
    "MEMORY REWRITTEN BY SYSTEM 7",
  ];
  const corrupted = entries.map(entry => ({
    ...entry,
    content: corruptedTexts[Math.floor(Math.random() * corruptedTexts.length)],
    title: Math.random() > 0.5 ? '[CORRUPTED]' : entry.title,
    corrupted: true,
  }));
  saveEntries(corrupted);
}

// Auto-save functionality for "Still Alive" feature
export function getAutoSave(): AutoSaveData | null {
  try {
    const raw = localStorage.getItem('madlog_autosave');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveAutoSave(data: AutoSaveData): void {
  localStorage.setItem('madlog_autosave', JSON.stringify(data));
}

export function clearAutoSave(): void {
  localStorage.removeItem('madlog_autosave');
}

export function addAutoSaveSnapshot(content: string): void {
  const existing = getAutoSave();
  const snapshot = {
    content,
    timestamp: Date.now(),
  };
  
  if (existing) {
    existing.snapshots.push(snapshot);
    // Keep only last 10 snapshots
    if (existing.snapshots.length > 10) {
      existing.snapshots.shift();
    }
    existing.content = content;
    existing.timestamp = Date.now();
    saveAutoSave(existing);
  } else {
    saveAutoSave({
      content,
      title: '',
      timestamp: Date.now(),
      snapshots: [snapshot],
    });
  }
}

export function getRecoverableContent(): string | null {
  const autoSave = getAutoSave();
  if (!autoSave || autoSave.snapshots.length === 0) return null;
  
  // Get the most recent snapshot that's older than 20 seconds
  const now = Date.now();
  const validSnapshots = autoSave.snapshots.filter(s => now - s.timestamp > 20000);
  
  if (validSnapshots.length === 0) return null;
  return validSnapshots[validSnapshots.length - 1].content;
}
